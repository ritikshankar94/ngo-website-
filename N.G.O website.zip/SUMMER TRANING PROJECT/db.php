<?php
error_reporting(1);
$server = "localhost" ;
$username = "ritik" ;
$password = "Nz*mkeY_Dbw8e2zn" ;
$dbname = "ritik" ;
 
$conn = mysqli_connect($server, $username, $password, $dbname);
 
?>
